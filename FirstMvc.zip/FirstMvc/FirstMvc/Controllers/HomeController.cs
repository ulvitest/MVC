﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace FirstMvc.Controllers
{
    public class HomeController:Controller
    {
        public HomeController()
        {
        }


        public IActionResult Index(int id)
        {
            //return Ok();
            //return Json();
            return Content($"Hi P125 {id}");

        }
        public IActionResult About()
        {
            return Content("about p125");
        }
    }
}
